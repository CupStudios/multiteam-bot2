module.exports = {
  name: 'dep',
  description: 'Deposita dinero en el banco.',
  execute: async ({ message, args, remitenteId, economia, guardarDatos, ARCHIVO_ECONOMIA }) => {
    // args[0] será la cantidad o la palabra "all"
    const cantidad = args[0]; 
    const user = economia[remitenteId];
    const monto = cantidad === 'all' ? user.wallet : parseInt(cantidad, 10);

    if (!monto || monto <= 0 || monto > user.wallet) {
        return message.reply('❌ Cantidad inválida o no tienes suficientes Yenes en tu billetera.');
    }

    user.wallet -= monto;
    user.bank += monto;
    
    guardarDatos(ARCHIVO_ECONOMIA, economia);
    return message.reply(`🏛️ Has depositado **${monto} Yenes** en el banco.`);
  }
};