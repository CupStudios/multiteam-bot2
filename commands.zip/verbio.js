const { MessageMedia } = require('whatsapp-web.js');
const path = require('path');
const fs = require('fs');

module.exports = {
  name: 'verficha', 
  execute: async ({ client, message, baseDeDatosBios, construirId }) => {
    try {
      const menciones = await message.getMentions();
      let objetivoId;
      let contactoObjetivo;
      
      if (menciones.length > 0) {
        objetivoId = construirId(menciones[0].id._serialized);
        contactoObjetivo = menciones[0];
      } else {
        const idCrudo = message.author || message.from;
        objetivoId = construirId(idCrudo);
        contactoObjetivo = await client.getContactById(objetivoId);
      }

      const numeroUsuario = contactoObjetivo.id ? contactoObjetivo.id.user : objetivoId.split('@')[0];
      const presentacion = baseDeDatosBios[objetivoId];

      if (!presentacion) {
        const mensajeError = menciones.length > 0 
          ? '⚠️ Esta persona no tiene una ficha registrada.' 
          : '⚠️ Aún no tienes una ficha. ¡Crea una enviando *!ficha*!';
        return message.reply(mensajeError); // Este ya funciona bien
      }

      const caption = `*Ficha de @${numeroUsuario}*:\n\n${presentacion.descripcion}`;

      // --- CAMBIO AQUÍ: Enviando media como respuesta ---
      if (presentacion.fotoNombre) {
        const rutaArchivo = path.join(__dirname, '..', 'media', 'bios', presentacion.fotoNombre);

        if (fs.existsSync(rutaArchivo)) {
          const media = MessageMedia.fromFilePath(rutaArchivo);
          
          // En whatsapp-web.js, para responder con media se usa:
          // message.reply(media, chatID (opcional), opciones)
          return await message.reply(media, undefined, {
            caption: caption,
            mentions: [objetivoId]
          });
        } else {
          await message.reply('⚠️ _Nota: La imagen se perdió en el servidor. Mostrando solo texto..._');
        }
      }

      // --- CAMBIO AQUÍ: Enviando solo texto como respuesta ---
      return await message.reply(caption, undefined, {
        mentions: [objetivoId]
      });

    } catch (error) {
      console.error('Error al ejecutar !verficha:', error);
      return message.reply('❌ Ocurrió un error interno.');
    }
  }
};