module.exports = {
  name: 'personajes',
  execute: async ({ message, baseDeDatosBios }) => {
    const ids = Object.keys(baseDeDatosBios);

    if (ids.length === 0) {
      return message.reply('🎭 No hay personajes registrados todavía.');
    }

    let texto = `🎭 *LISTA DE PERSONAJES* 🎭\n\n`;

    for (const id of ids) {
      const datos = baseDeDatosBios[id];
      // Usamos el campo "personaje" que guardamos en setbio
      const nombreMostrar = datos.personaje || "Sin nombre (usa !setbio)";
      texto += `• ${nombreMostrar}\n`;
    }

    texto += `\n> 💡 Usa *!verbio @usuario* para ver la ficha completa.`;

    return message.reply(texto);
  }
};