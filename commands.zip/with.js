module.exports = {
  name: 'with',
  execute: async ({ message, args, remitenteId, economia, guardarDatos, ARCHIVO_ECONOMIA }) => {
    const cantidad = args[0];
    const user = economia[remitenteId];
    const monto = cantidad === 'all' ? user.bank : parseInt(cantidad, 10);

    if (!monto || monto <= 0 || monto > user.bank) {
      return message.reply('❌ Cantidad inválida o no tienes ese dinero en el banco.');
    }

    user.bank -= monto;
    user.wallet += monto;
    
    guardarDatos(ARCHIVO_ECONOMIA, economia);
    return message.reply(`💰 Has retirado **${monto} Yenes** del banco.`);
  }
};