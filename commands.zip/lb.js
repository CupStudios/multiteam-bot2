module.exports = {
  name: 'lb',
  execute: async ({ client, message, economia }) => {
    const ids = Object.keys(economia);
    
    if (ids.length === 0) {
      return message.reply('💴 El sistema de economía está vacío todavía.');
    }

    // Convertimos el objeto en un array para poder ordenarlo
    const ranking = ids.map(id => ({
      id,
      total: (economia[id].wallet || 0) + (economia[id].bank || 0)
    }));

    // Ordenamos de mayor a menor
    ranking.sort((a, b) => b.total - a.total);

    // Tomamos los 10 primeros
    const top10 = ranking.slice(0, 10);
    
    let texto = `🏆 *TOP 10 - LOS MÁS RICOS* 🏆\n\n`;

    for (let i = 0; i < top10.length; i++) {
      const item = top10[i];
      try {
        // Obtenemos el contacto para mostrar el nombre real de WhatsApp
        const contact = await client.getContactById(item.id);
        const nombre = contact.pushname || item.id.split('@')[0];
        
        const medalla = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '•';
        texto += `${medalla} *${nombre}*: 💴 ${item.total} Yenes\n`;
      } catch {
        texto += `• *Usuario* (${item.id.split('@')[0]}): 💴 ${item.total} Yenes\n`;
      }
    }

    return message.reply(texto);
  }
};