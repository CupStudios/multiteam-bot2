const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'setbio',
  execute: async ({ message, remitenteId, baseDeDatosBios, guardarDatos, ARCHIVO_BIOS }) => {
    // Dividimos el texto usando el separador "|"
    const contenido = message.body.slice(8).trim();
    const [nombre, ...descArray] = contenido.split('|');
    const descripcion = descArray.join('|').trim();

    if (!nombre || !descripcion) {
      return message.reply('⚠️ Formato incorrecto. Usa:\n*!setbio Nombre del Personaje | Descripción*');
    }

    let nombreArchivo = null;

    if (message.hasMedia) {
      const multimedia = await message.downloadMedia();
      const carpetaBios = path.join(__dirname, '..', 'media', 'bios');
      if (!fs.existsSync(carpetaBios)) fs.mkdirSync(carpetaBios, { recursive: true });

      const extension = multimedia.mimetype.split('/')[1] || 'jpg';
      nombreArchivo = `${remitenteId.split('@')[0]}.${extension}`;
      fs.writeFileSync(path.join(carpetaBios, nombreArchivo), multimedia.data, { encoding: 'base64' });
    }

    // Guardamos el NOMBRE del personaje por separado
    baseDeDatosBios[remitenteId] = {
      personaje: nombre.trim(),
      descripcion: descripcion,
      fotoNombre: nombreArchivo
    };

    guardarDatos(ARCHIVO_BIOS, baseDeDatosBios);
    return message.reply(`✅ Personaje **${nombre.trim()}** registrado con éxito.`);
  }
};