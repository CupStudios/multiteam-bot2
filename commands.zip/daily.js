module.exports = {
  name: 'daily',
  execute: async ({ message, remitenteId, economia, guardarDatos, ARCHIVO_ECONOMIA }) => {
    const ahora = Date.now();
    const unDia = 24 * 60 * 60 * 1000;
    const user = economia[remitenteId];

    if (ahora - user.lastDaily < unDia) {
      const horasRestantes = Math.ceil((unDia - (ahora - user.lastDaily)) / 1000 / 60 / 60);
      return message.reply(`🌙 Ya reclamaste tu recompensa. Vuelve en ${horasRestantes} horas.`);
    }

    if (ahora - user.lastDaily < unDia * 2) {
      user.dailyStreak++;
    } else {
      user.dailyStreak = 1;
    }

    const premio = 500 + user.dailyStreak * 50;
    user.wallet += premio;
    user.lastDaily = ahora;
    
    guardarDatos(ARCHIVO_ECONOMIA, economia);
    return message.reply(`🎁 ¡Recompensa diaria! Has recibido **${premio} Yenes**.\n🔥 Racha actual: ${user.dailyStreak} días.`);
  }
};