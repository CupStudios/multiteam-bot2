module.exports = {
  name: 'rob',
  execute: async ({ message, remitenteId, economia, guardarDatos, ARCHIVO_ECONOMIA, initUser }) => {
    const menciones = await message.getMentions();
    if (menciones.length === 0) return message.reply('❌ Menciona a quién quieres robar.');

    const victimaId = initUser(menciones[0].id);
    const ahora = Date.now();

    if (ahora - economia[remitenteId].lastRob < 30 * 60 * 1000) {
      return message.reply('🚨 La policía te busca, espera 30 min para volver a robar.');
    }

    if (economia[victimaId].wallet < 100) {
      return message.reply('Esa persona es demasiado pobre para robarle.');
    }

    const exito = Math.random() < 0.4;
    if (exito) {
      const robado = Math.floor(economia[victimaId].wallet * (Math.random() * 0.5));
      economia[remitenteId].wallet += robado;
      economia[victimaId].wallet -= robado;
      await message.reply(`🥷 ¡Éxito! Le robaste **${robado} Yenes** a @${menciones[0].id.user}`, {
        mentions: [menciones[0].id._serialized]
      });
    } else {
      const multa = 200;
      economia[remitenteId].wallet = Math.max(0, economia[remitenteId].wallet - multa);
      await message.reply(`🚓 ¡Te atraparon! Pagaste **${multa} Yenes** de multa.`);
    }

    economia[remitenteId].lastRob = ahora;
    guardarDatos(ARCHIVO_ECONOMIA, economia);
  }
};