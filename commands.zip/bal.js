module.exports = {
  name: 'bal',
  execute: async ({ message, remitenteId, economia, initUser }) => {
    const menciones = await message.getMentions();
    // Si hay mención buscamos a ese usuario, si no, usamos el remitente
    const targetId = initUser(menciones.length > 0 ? menciones[0].id : remitenteId);
    const targetName = menciones.length > 0 ? menciones[0].pushname || menciones[0].id.user : 'Tu';

    const { wallet, bank } = economia[targetId];

    return message.reply(`🏦 *Estado Financiero de ${targetName}*\n\n· 💴 **Billetera:** ${wallet} Yenes\n· 🏛️ **Banco:** ${bank} Yenes\n· 💰 **Total:** ${wallet + bank} Yenes`);
  }
};