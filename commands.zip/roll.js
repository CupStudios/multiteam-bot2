module.exports = {
  name: 'roll',
  execute: async ({ message, remitenteId, economia, guardarDatos, ARCHIVO_ECONOMIA }) => {
    const ahora = Date.now();
    const cooldown = 2 * 60 * 1000;
    const user = economia[remitenteId];

    if (!user.lastRoll) user.lastRoll = 0;

    if (ahora - user.lastRoll < cooldown) {
      const restante = Math.ceil((cooldown - (ahora - user.lastRoll)) / 1000 / 60);
      return message.reply(`⌛ Estás en cooldown. Vuelve a tirar el dado en ${restante} minutos.`);
    }
    
    const exito = Math.random() < 0.4;
    if (exito) {
      const ganancia = Math.floor(Math.random() * (300 - 100 + 1)) + 100;
      user.wallet += ganancia;
      await message.reply(`🎲 ¡Tiraste los dados y ganaste! Recibes **${ganancia} Yenes**.`);
    } else {
      const multa = 200;
      user.wallet = Math.max(0, user.wallet - multa);
      await message.reply(`🎲 Los dados no te favorecieron. ¡Perdiste **${multa} Yenes**! Suerte para la próxima.`);
    }

    user.lastRoll = ahora;
    guardarDatos(ARCHIVO_ECONOMIA, economia);
  }
};