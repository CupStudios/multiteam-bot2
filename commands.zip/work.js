module.exports = {
  name: 'work',
  description: 'Trabaja para ganar Yenes (10 min de cooldown).',
  execute: async ({ message, remitenteId, economia, guardarDatos, ARCHIVO_ECONOMIA }) => {
    const ahora = Date.now();
    const cooldown = 10 * 60 * 1000;

    if (ahora - economia[remitenteId].lastWork < cooldown) {
      const restante = Math.ceil((cooldown - (ahora - economia[remitenteId].lastWork)) / 1000 / 60);
      return message.reply(`⌛ Estás cansado. Vuelve a trabajar en ${restante} minutos.`);
    }

    const sueldo = Math.floor(Math.random() * (200 - 50 + 1)) + 50;
    economia[remitenteId].wallet += sueldo;
    economia[remitenteId].lastWork = ahora;
    
    guardarDatos(ARCHIVO_ECONOMIA, economia);
    return message.reply(`⚒️ Trabajaste duro y ganaste **${sueldo} Yenes**.`);
  }
};